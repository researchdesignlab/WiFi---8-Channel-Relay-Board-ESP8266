package com.example.a619.sampleapplication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
//import com.relayrdlwifiswitch8newver2.R;

public class EightChannelRelayClass extends AppCompatActivity {

    SharedPreferences sharedPreferences;
	RadioButton rb1,rb2,rb3,rb4,rb5,rb6,rb7,rb8;
	int SERVER_PORT=8080;
	String IP_ADDRESS="";
	PrintWriter out;
	String tMsg;
	private TCPClient mTcpClient = new TCPClient();
	String t1,t2,t3;
	private int pValue=0;
	TextView statusTextView,textView5,textView6,textView7,textView8,textView9,textView10,textView11,textView12;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_eight_channel_relay);

		statusTextView= (TextView) findViewById(R.id.statusTextView);

		if (android.os.Build.VERSION.SDK_INT > 9)
		{
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}
		new connectTask().execute("");

        textView5=(TextView)findViewById(R.id.textView5);
        textView6=(TextView)findViewById(R.id.textView6);
        textView7=(TextView)findViewById(R.id.textView7);
        textView8=(TextView)findViewById(R.id.textView8);
        textView9=(TextView)findViewById(R.id.textView9);
        textView10=(TextView)findViewById(R.id.textView10);
        textView11=(TextView)findViewById(R.id.textView11);
        textView12=(TextView)findViewById(R.id.textView12);


        sharedPreferences = getSharedPreferences("SharedPreference",0);

        textView5.setText(sharedPreferences.getString("relayOne","Light1"));
        textView6.setText(sharedPreferences.getString("relayTwo","Light2"));
        textView7.setText(sharedPreferences.getString("relayThree","Light3"));
        textView8.setText(sharedPreferences.getString("relayFour","Light4"));
        textView9.setText(sharedPreferences.getString("relayFive","Light5"));
        textView10.setText(sharedPreferences.getString("relaySix","Light6"));
        textView11.setText(sharedPreferences.getString("relaySeven","Light7"));
        textView12.setText(sharedPreferences.getString("relayEight","Light8"));

		rb1 = (RadioButton) findViewById(R.id.radioButton1);
		rb2 = (RadioButton) findViewById(R.id.radioButton2);
		rb3 = (RadioButton) findViewById(R.id.radioButton3);
		rb4 = (RadioButton) findViewById(R.id.radioButton4);
		rb5 = (RadioButton) findViewById(R.id.radioButton5);
		rb6 = (RadioButton) findViewById(R.id.radioButton6);
		rb7 = (RadioButton) findViewById(R.id.radioButton7);
		rb8 = (RadioButton) findViewById(R.id.radioButton8);

//		statusTextView= (TextView) findViewById(R.id.statusTextView);

		SharedPreferences pre = this.getSharedPreferences("pref", 0);
		SERVER_PORT = Integer.parseInt(pre.getString("ghj", "10"));
		IP_ADDRESS = pre.getString("savedDatasd","192.168.4.1");

		statusTextView.setText("IP:"+IP_ADDRESS+" PORT:"+SERVER_PORT);


//		Toast.makeText(getApplicationContext(),String.valueOf(SERVER_PORT)+" "+String.valueOf(IP_ADDRESS),Toast.LENGTH_SHORT).show();

//		new Thread(new Runnable() {
//			@Override
//			   public void run() {
//			    try{
//			     //Create a server socket object and bind it to a port
//			     ServerSocket socServer = new ServerSocket(SERVER_PORT);
//			     //Create server side client socket reference
//				/*The below two paramters in the Socket constructor added by added by Gaurav Duth Baliga to check if the socket connection establishes or not */
//			     Socket socClient = new Socket(IP_ADDRESS,SERVER_PORT);
//			     //Infinite loop will listen for client requests to connect
//			     while (true) {
//			      //Accept the client connection and hand over communication to server side client socket
//			      //For each client new instance of AsyncTask will be created
//			      ServerAsyncTask serverAsyncTask = new ServerAsyncTask();
//			      //Start the AsyncTask execution
//			      //Accepted client socket object will pass as the parameter
////			      serverAsyncTask.execute(new Socket[] {socClient});
//					 serverAsyncTask.execute(new Socket[] {socClient});
//			     }
//			    } catch (IOException e) {
//			     e.printStackTrace();
//			    }
//			   }
//		}).start();
	}
	
//	public void sendMessage(String msg)
//	{
//		if (out != null && !out.checkError()) {
//            out.write(msg);
//            out.flush();
//        }
//	}


//	class ServerAsyncTask extends AsyncTask<Socket, Void, String> {
//		  //Background task which serve for the client
//		  @Override
//		  protected String doInBackground(Socket... params) {
//		   String result = null;
//		   //Get the accepted socket object
//		   Socket mySocket = params[0];
//		   try {
//		    //Get the data input stream comming from the client
//		    InputStream is = mySocket.getInputStream();
//		    //Get the output stream to the client
//		    out = new PrintWriter(
//		      mySocket.getOutputStream(), true);
//		    //Write data to the data output stream
//		    //out.println("Hello from server");
//		    //Buffer the data input stream
//		    BufferedReader br = new BufferedReader(
//		      new InputStreamReader(is));
//		    //Read the contents of the data buffer
//		    result = br.readLine();
//		    //Close the client connection
//		   // mySocket.close();
//		   } catch (IOException e) {
//		    e.printStackTrace();
//		   }
//		   return result;
//		  }
//
//		  @Override
//		  protected void onPostExecute(String s) {
//		   //After finishing the execution of background task data will be write the text view
//		   //tvClientMsg.setText(s);
//		  }
//	}
	
	public void inser1(View v)
	{
		tMsg = "1N"+"\r";
		rb1.setChecked(true);
		mTcpClient.sendMessage(tMsg);
    }
	
	public void inser11(View v)
	{
		tMsg = "1F"+"\r";
		rb1.setChecked(false);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser2(View v)
	{
		tMsg = "2N"+"\r";
		rb2.setChecked(true);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser22(View v)
	{
		tMsg = "2F"+"\r";
		rb2.setChecked(false);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser3(View v)
	{
		tMsg = "3N"+"\r";
		rb3.setChecked(true);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser33(View v)
	{
		tMsg = "3F"+"\r";
		rb3.setChecked(false);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser4(View v)
	{
		tMsg = "4N"+"\r";
		rb4.setChecked(true);
		mTcpClient.sendMessage(tMsg);
        
		
	}
	
	public void inser44(View v)
	{
		tMsg = "4F"+"\r";
		rb4.setChecked(false);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser5(View v)
	{
		tMsg = "5N"+"\r";
		rb5.setChecked(true);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser55(View v)
	{
		tMsg = "5F"+"\r";
		rb5.setChecked(false);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser6(View v)
	{
		tMsg = "6N"+"\r";
		rb6.setChecked(true);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser66(View v)
	{
		tMsg = "6F"+"\r";
		rb6.setChecked(false);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser7(View v)
	{
	    tMsg = "7N"+"\r";
		rb7.setChecked(true);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser77(View v)
	{
		tMsg = "7F"+"\r";
		rb7.setChecked(false);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser8(View v)
	{
		tMsg = "8N"+"\r";
		rb8.setChecked(true);
	    mTcpClient.sendMessage(tMsg);
        
	}
	
	public void inser88(View v)
	{
		tMsg = "8F"+"\r";
		rb8.setChecked(false);
		mTcpClient.sendMessage(tMsg);
	}
	
	public void aon(View v)
	{
		tMsg = "AN"+"\r";
		rb1.setChecked(true);
		rb2.setChecked(true);
		rb3.setChecked(true);
		rb4.setChecked(true);
		rb5.setChecked(true);
		rb6.setChecked(true);
		rb7.setChecked(true);
		rb8.setChecked(true);
		mTcpClient.sendMessage(tMsg);
        
	}
	
	public void aof(View v)
	{
		tMsg = "AF"+"\r";
		rb1.setChecked(false);
		rb2.setChecked(false);
		rb3.setChecked(false);
		rb4.setChecked(false);
		rb5.setChecked(false);
		rb6.setChecked(false);
		rb7.setChecked(false);
		rb8.setChecked(false);
		mTcpClient.sendMessage(tMsg);
        
	}
	

	/*The below connect method added by Gaurav Duth Baliga for the 8 channel relay button to maintain the stable connection on the date 23-March-2018*/
	public void connect(View view){
		try
		{
			super.onResume();
			if (mTcpClient != null) {

				if(!mTcpClient.isClosed())
				{
					mTcpClient.stopClient();
					mTcpClient.Close();

				}
			}
			new connectTask().execute("");
			//ipporttxt.setText("IP :"+ t1+"  PORT:"+t2);
			// Toast.makeText(getApplicationContext(), "OnResume called", Toast.LENGTH_SHORT).show();
		}catch(Exception ex)
		{
			Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_SHORT).show();
		}
		Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_SHORT).show();
	}

	public class connectTask extends AsyncTask<String,String,TCPClient> {

		@Override
		protected TCPClient doInBackground(String... message) {

			//we create a TCPClient object and
			mTcpClient = new TCPClient(new TCPClient.OnMessageReceived() {
				@Override
				//here the messageReceived method is implemented
				public void messageReceived(String message) {
					//this method calls the onProgressUpdate
					publishProgress(message);
				}
			});
			mTcpClient.run(IP_ADDRESS,SERVER_PORT);
			return null;
		}

		@Override
		protected void onProgressUpdate(String... values) {
			super.onProgressUpdate(values);

			//in the arrayList we add the messaged received from server
			// arrayList.add(values[0]);
			// notify the adapter that the data set has changed. This means that new message received
			// from server was added to the list
			// mAdapter.notifyDataSetChanged();
		}
	}



	@Override
	protected void onPause() {
		try
		{
			super.onPause();
		}catch(Exception ex)
		{

		}

		//Toast.makeText(getApplicationContext(), "onPause called", Toast.LENGTH_LONG).show();
	}
	@Override
	protected void onStop() {

		try
		{
			super.onStop();  // Always call the superclass method first

			if (mTcpClient != null) {

				if(!mTcpClient.isClosed())
				{
					mTcpClient.stopClient();

					mTcpClient.Close();
				}
			}

			// Toast.makeText(getApplicationContext(), "onStop called", Toast.LENGTH_SHORT).show();
		}catch(Exception ex)
		{

		}

	}

	@Override
	protected void onResume() {
		// Ideally should implement onResume() and onPause()
		// to take appropriate action when the activity looses focus

		try
		{
			super.onResume();
			if (mTcpClient != null) {

				if(!mTcpClient.isClosed())
				{
					mTcpClient.stopClient();
					mTcpClient.Close();
				}
			}
			new connectTask().execute("");
//			ipporttxt.setText("IP :"+ t1+"  PORT:"+t2);
			//Toast.makeText(getApplicationContext(), "OnResume called", Toast.LENGTH_SHORT).show();

		}catch(Exception ex)
		{

		}
	}
}
