package com.example.a619.sampleapplication;





import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

//import com.relayrdlwifiswitch8newver2.R;

public class Ssr extends AppCompatActivity {

	EditText et1,et2,et3;
	RadioButton rb1,rb2;
	Button b1,b2;
	String s1,s2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ssr);
		
		SharedPreferences pre = getSharedPreferences("pref", 0);
		s1 = pre.getString("savedDatasd", "10");
		s2 = pre.getString("ghj", "10");
		
		/*if(!s1.equals("10")){
			
			Intent i = new Intent(this, Rdlwifiswi.class);
			startActivity(i);
		}*/
		
		
		
		
		et1 = (EditText)findViewById(R.id.editText1);
		et2 = (EditText)findViewById(R.id.editText2);
//		et3 = (EditText)findViewById(R.id.editText3);
//		rb1 = (RadioButton)findViewById(R.id.radioButton1);
//		rb2 = (RadioButton)findViewById(R.id.radioButton2);
		b1 = (Button) findViewById(R.id.button1);
//		b2 = (Button) findViewById(R.id.button2);
		
	}

//	public void ijk(View v)
//	{
//		rb2.setChecked(false);
//		et1.setVisibility(View.VISIBLE);
//		et2.setVisibility(View.VISIBLE);
////		et3.setVisibility(View.INVISIBLE);
//		b1.setVisibility(View.VISIBLE);
////		b2.setVisibility(View.INVISIBLE);
//	}
//
//	public void ins(View v)
//	{
//		rb1.setChecked(false);
//		et1.setVisibility(View.INVISIBLE);
//		et2.setVisibility(View.INVISIBLE);
//		et3.setVisibility(View.INVISIBLE);
//		b1.setVisibility(View.INVISIBLE);
//		b2.setVisibility(View.INVISIBLE);
//	}
//
	public void ion(View v)
	{
		String host,port,av;
		host = et1.getText().toString();
		port = et2.getText().toString();
		av = host+","+port;

		if(host.equals("")){
			Toast.makeText(getApplicationContext(),"Please Enter the IP Address Properly",Toast.LENGTH_SHORT).show();
		}

		if(port.equals("")){
			Toast.makeText(getApplicationContext(),"Please Enter Port Number Properly",Toast.LENGTH_SHORT).show();
		}

		if(!host.equals("")&&!port.equals("")) {
			SharedPreferences preferences = getSharedPreferences("pref", 0);
			SharedPreferences.Editor editor = preferences.edit();
			//"savedData" is the key that we will use in onCreate to get the saved data
			//mDataString is the string we want to save
			editor.putString("savedDatasd", host);
			editor.putString("ghj", port);
			// commit the edits
			editor.commit();
			editor.apply();

			Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
			Intent intent = new Intent(getApplicationContext(),MainActivity.class);
			startActivity(intent);
		}

	}

	public void setRelayName(View view){
		Intent intent = new Intent(getApplicationContext(),RelayName.class);
		startActivity(intent);
	}
}
