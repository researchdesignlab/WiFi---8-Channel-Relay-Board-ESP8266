package com.example.a619.sampleapplication;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RelayName extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    EditText relayOneEditText,relayTwoEditText,relayThreeEditText,relayFourEditText,relayFiveEditText,relaySixEditText,relaySevenEditText,relayEightEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relay_name);
        relayOneEditText=(EditText)findViewById(R.id.relayOneEditText);
        relayTwoEditText=(EditText)findViewById(R.id.relayTwoEditText);
        relayThreeEditText=(EditText)findViewById(R.id.relaythreeEditText);
        relayFourEditText=(EditText)findViewById(R.id.relayFourEditText);
        relayFiveEditText=(EditText)findViewById(R.id.relayFiveEditText);
        relaySixEditText=(EditText)findViewById(R.id.relaySixEditText);
        relaySevenEditText=(EditText)findViewById(R.id.relaySevenEditText);
        relayEightEditText=(EditText)findViewById(R.id.relayEightEditText);
    }

    public void saveNames(View view){

        sharedPreferences = getSharedPreferences("SharedPreference",0);
        editor = sharedPreferences.edit();

        String relayOne=relayOneEditText.getText().toString();
        String relayTwo=relayTwoEditText.getText().toString();
        String relayThree=relayThreeEditText.getText().toString();
        String relayFour=relayFourEditText.getText().toString();
        String relayFive=relayFiveEditText.getText().toString();
        String relaySix=relaySixEditText.getText().toString();
        String relaySeven=relaySevenEditText.getText().toString();
        String relayEight=relayEightEditText.getText().toString();

        if(relayOne.equals("")){
            Toast.makeText(getApplicationContext(),"Enter a name to relay one",Toast.LENGTH_SHORT).show();
        }else{
            editor.putString("relayOne",relayOne);
            editor.apply();
            editor.commit();
        }
        if(relayTwo.equals("")){
            Toast.makeText(getApplicationContext(),"Enter a name to relay two",Toast.LENGTH_SHORT).show();
        }else{
            editor.putString("relayTwo",relayTwo);
            editor.apply();
            editor.commit();
        }
        if(relayThree.equals("")){
            Toast.makeText(getApplicationContext(),"Enter a name to relay three",Toast.LENGTH_SHORT).show();
        }else{
            editor.putString("relayThree",relayThree);
            editor.apply();
            editor.commit();
        }
        if(relayFour.equals("")){
            Toast.makeText(getApplicationContext(),"Enter a name to relay four",Toast.LENGTH_SHORT).show();
        }else{
            editor.putString("relayFour",relayFour);
            editor.apply();
            editor.commit();
        }
        if(relayFive.equals("")){
            Toast.makeText(getApplicationContext(),"Enter a name to relay five",Toast.LENGTH_SHORT).show();
        }else{
            editor.putString("relayFive",relayFive);
            editor.apply();
            editor.commit();
        }
        if(relaySix.equals("")){
            Toast.makeText(getApplicationContext(),"Enter a name to relay six",Toast.LENGTH_SHORT).show();
        }else{
            editor.putString("relaySix",relaySix);
            editor.apply();
            editor.commit();
        }
        if(relaySeven.equals("")){
            Toast.makeText(getApplicationContext(),"Enter a name to relay seven",Toast.LENGTH_SHORT).show();
        }else{
            editor.putString("relaySeven",relaySeven);
            editor.apply();
            editor.commit();
        }
        if(relayEight.equals("")){
            Toast.makeText(getApplicationContext(),"Enter a name to relay eight",Toast.LENGTH_SHORT).show();
        }else{
            editor.putString("relayEight",relayEight);
            editor.apply();
            editor.commit();
        }
   }

}
