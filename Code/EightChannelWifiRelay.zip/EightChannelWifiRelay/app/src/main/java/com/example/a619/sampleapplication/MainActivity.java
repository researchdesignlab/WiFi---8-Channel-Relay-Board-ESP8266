package com.example.a619.sampleapplication;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
//import com.relayrdlwifiswitch8newver2.R;

public class MainActivity extends AppCompatActivity implements AnimationListener{

	Animation animFadein;
	ImageView iv;
	int i=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		iv = (ImageView)findViewById(R.id.imageView1);
		 animFadein = AnimationUtils.loadAnimation(getApplicationContext(),R.drawable.rotate);
		 
		 animFadein.setAnimationListener(this);
		 iv.startAnimation(animFadein);
	}

	public void Start(View v)
	{
		Intent i = new Intent(this, EightChannelRelayClass.class);
		//i.putExtra("id", av);
		startActivity(i);
	}
	

	@Override
	public void onAnimationEnd(Animation animation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onAnimationRepeat(Animation animation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onAnimationStart(Animation animation) {
		// TODO Auto-generated method stub
		
	}
	
	public void config(View v)
	{
		Intent i = new Intent(this, Ssr.class);
		startActivity(i);
	}

}
